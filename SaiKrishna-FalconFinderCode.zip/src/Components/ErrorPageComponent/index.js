import React from 'react'

 function ErrorPage(props) {
    return (
        <div >
            {props.error}
        </div>
    )
}
export default ErrorPage