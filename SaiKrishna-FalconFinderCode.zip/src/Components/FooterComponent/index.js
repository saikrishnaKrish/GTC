import React from 'react';
//importing styles
import './FooterComponentStyles.css';


/**
 * 
 * @renders the footer on the screen
 */
function FooterComponent() {
    return (
        <footer >
            Coding problem -www.greektrust.in/findingfalcone
        </footer>
    )
}

export default FooterComponent