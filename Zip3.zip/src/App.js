import './App.css';

import HeaderComponent from './Components/HeaderComponent';
import SubHeader from './Components/HeaderComponent/SubHeader';
import FooterComponent from './Components/FooterComponent';

import RoutingComponent from './Components/RouterComponent'
import GlobalContextProvider from './Context/GlobalContextProvider';


function App() {
  return (
    <div className="App">
       <GlobalContextProvider>
              <HeaderComponent />
              <SubHeader />
                <RoutingComponent/>
               <FooterComponent /> 
     </GlobalContextProvider>
    </div>
  );
}

export default App;
