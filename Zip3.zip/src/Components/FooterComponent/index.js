import React from 'react'
import './FooterComponentStyles.css'
function FooterComponent() {
    return (
        <footer >
            Coding problem -www.greektrust.in/findingfalcone
        </footer>
    )
}

export default FooterComponent