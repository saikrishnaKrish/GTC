import React from 'react'
import './HeaderComponentStyle.css'
import { withRouter,Link } from 'react-router-dom';
import {

    Navbar,
    NavbarBrand,
    Nav,
    NavItem,
 
  } from 'reactstrap';
  

function HeaderComponent() {
    return (
        <div>
<Navbar color="light" light expand="md">
        <NavbarBrand className="brand-name">
            <Link to="/">Greek Trust</Link></NavbarBrand>
        <Nav className="ml-auto" navbar>
            <NavItem >
            <span >Reset</span> 
            <span>|</span>
            <span>GreekTrustHome</span>
            </NavItem>
            </Nav>       
         </Navbar>       
            
  
        </div>
    )
}

export default withRouter(HeaderComponent);