import React, { Component } from 'react';


import MainComponent from '../Components/MainComponent'



export class HomePage extends Component {
    render() {
        return (
                <MainComponent/>     
        )
    }
}

export default HomePage
