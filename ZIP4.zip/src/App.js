import './App.css';

import RoutingComponent from './Components/RouterComponent'



function App() {
  return (
    <div className="App">

      <RoutingComponent />

    </div>
  );
}

export default App;
