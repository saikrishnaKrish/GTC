import React from 'react'

function SubHeader() {
    return (
        <div>
            <h1> Finding Falcone!!!</h1>
        </div>
    )
}

export default SubHeader;