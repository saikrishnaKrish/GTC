import React from 'react'

function SubHeader() {
    return (
        <div>
            Finding Falcone!!!
        </div>
    )
}

export default SubHeader;