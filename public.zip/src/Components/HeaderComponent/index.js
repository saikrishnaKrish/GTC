import React from 'react'

function HeaderComponent() {
    return (
        <div>
            Reset|GreekTrustHome
        </div>
    )
}

export default HeaderComponent;