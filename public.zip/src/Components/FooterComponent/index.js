import React from 'react'

function FooterComponent() {
    return (
        <div>
            Coding problem -www.greektrust.in/findingfalcone
        </div>
    )
}

export default FooterComponent